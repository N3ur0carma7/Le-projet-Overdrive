# Le-projet-Overdrive
La base du jeu serait une sandbox, où le joueur construit et dévelope son village/ville. La carte sera générée procéduralement et contiendra différentes salles/donjons, avec différentes mécaniques pour les résoudre (puzzle, énigme, boss, Shooter et des récompenses à la clef.
